﻿
$(document).ready(function() {

// PLUGIN SETUP
// last item should NOT have a comma 
var myPlugins = {
//"Plugin Menu Name" : "Plugin Folder Name",
//"Plugin Menu Name" : "Plugin Folder Name",
//"Plugin Menu Name" : "Plugin Folder Name"
};


// plugin folders must be in same folder as Design Studio help inside "Help Plugins" folder
//path = document.location.href.substring(0, document.location.href.indexOf("Design_Studio")) + "Help Plugins/"; //this is the original script from Scott
path = document.location.href.substring(0, document.location.href.lastIndexOf("/Help/")) + "/Help Plugins/";


// MENU
// adds plugins menu as last menu item
// does not run if plugin list above is empty
if (Object.keys(myPlugins).length > 0) { 
	$("ul.navigation").on("loaded", function () {
		$('ul.navigation').append('<li class="has-children" data-mc-id="4"><a href="javascript:void(0);">Plugins</a><ul class="sub-menu"></ul></li>');
		$.each( myPlugins, function( name, url ) {
			$('[data-mc-id="4"] ul.sub-menu').append("<li><a href='" + path + url + "/Default.htm'>" + name + "</a></li>");
		});
	});
}


// SEARCH RESULTS				
// adds plugin search result iframes to "plugins" div
// only runs in search results topic
// "icon.png" is stored in Content folder (Design Studio and each plugin)
fURL = window.location.pathname;
var filename = fURL.substring(fURL.lastIndexOf('/')+1);
if (filename == "search_results.htm") {
	if (Object.keys(myPlugins).length > 0) { 
		$(".main-section").on("loaded", function () {
			$.each( myPlugins, function(name, url) {
				nameID = name.replace(/\s+/g, '-').toLowerCase();
				icn = path + url + "/Content/icon.png";
				url = path + url + "/Content/search_results.htm";
				$('#plugins').append('<h2><img src="' + icn + '" /> ' + name + ' <button id="' + nameID + '"  onclick="expColl(\'#' + nameID + '\')">Collapse</button></h2><div class="results"><iframe id="' + nameID + '" src="' + url + location.search + '" width="100%" style="border: none"></iframe><div>');
			});
		});
	}

	$("button#searchPane").click(function() { expCollSP("#searchPane"); });
}

});


// expand/collapse Design Studio search results
function expCollSP(id) {
boxID = "div" + id;
	$(boxID).css('overflow-y', 'scroll');
	if ($(boxID).height() == 112) { $(boxID).animate({height: "37px"}); $("button" + id).html('Expand'); }
	else if ($(boxID).height() < 600) { $(boxID).animate({height: "600px"}); $("button" + id).html('Collapse'); }
	else if ($(boxID).height() >= 600) { $(boxID).animate({height: "37px"}); $("button" + id).html('Expand'); }
}


// expand/collapse plugin search results
// separate in case plugins need different functionality
function expColl(id) {
boxID = "iframe" + id;
	$(boxID).css('overflow-y', 'scroll');
	if ($(boxID).height() == 112) { $(boxID).animate({height: "37px"}); $("button" + id).html('Expand'); }
	else if ($(boxID).height() < 600) { $(boxID).animate({height: "600px"}); $("button" + id).html('Collapse'); }
	else if ($(boxID).height() >= 600) { $(boxID).animate({height: "37px"}); $("button" + id).html('Expand'); }
}
function logMySearch() {
	//1. GET parameters aren’t passed to frames so you need to call the parent
	//2. The arguments are passed as part of the hash, rather than the search
	var qTarget = "?q=";
	var hTarget = "?highlight=";
	var searchValue = window.location.search.toLowerCase();
	if (searchValue.indexOf(qTarget) > -1) {
		var term = getMyTerm(searchValue, qTarget)
		sendMySearchResult('SearchResult', term);
	} else if  (searchValue.indexOf(hTarget) > -1) {
		var term = getMyTerm(searchValue, hTarget)
		sendMySearchResult(term, searchValue);
	}
}
function getMyTerm(value, target) {
	var fragments = value.split(target);
	if (fragments.length > 1) {
		return fragments[1];
	} else if (fragments.length = 1) {
		return fragments[0];
	} else {
		return value;
	}
}

function sendMySearchResult(event, term) {
	ga('send', 'event', 'Search', event, term);
}