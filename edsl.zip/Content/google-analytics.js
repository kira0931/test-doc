﻿	var pathArray = window.location.pathname.split('/');
	var doccode = pathArray[4]+"|"+pathArray[2]+"|"+pathArray[3];
	
	//script block edited 2017/01/25 10:26
	//called as the window loads up
	window.onload = function() {
		logSearch();
	};
			
	/* <![CDATA[ */ 
	(function(i, s, o, g, r, a, m){i['GoogleAnalyticsObject'] = r;i[r] = i[r] || function(){ 
				(i[r].q = i[r].q || []).push(arguments)},i[r].l = 1 * new Date();a = s.createElement(o), 
		m = s.getElementsByTagName(o)[0];a.async = 1;a.src = g;m.parentNode.insertBefore(a, m) 
	})(window, document, 'script', 'https://www.google-analytics.com/analytics.js', 'ga'); 
ga('create', 'UA-78867495-1', 'auto'); 
ga('send', 'pageview'); 
			/* ]]> */

sendEventToGA(doccode, "View", "pageview");

function sendEventToGA(releaseVersion, eventType, label)
{
	ga('send', 'event', releaseVersion, eventType, label);
}

function localSendToGA(label) {
	var version = doccode;
	var eventType = "feedback";
	sendEventToGA(version, eventType, label);
}	
			/* <![CDATA[ */ 
			//log a search
			//get the URL parameters, if they exist and pass them to Google Analytics
function logSearch(){
	/* If current page has a ?Highlight=xxx parameter, then record it as a search result event */
	//1. GET parameters aren’t passed to frames so you need to call the parent
	//2. The arguments are passed as part of the hash, rather than the search
	var hash = parent.document.location.hash;
	if (hash.indexOf('?Highlight=') > -1) {
		var fragments = hash.split('?Highlight=');
		if (fragments.length > 1) {
			ga('send', 'event', 'Search', 'SearchResult', fragments[1]);
		} else 	if (fragments.length = 1) {
			ga('send', 'event', 'Search', 'SearchResult', fragments[0]);
		} else {
			ga('send', 'event', 'Search', 'SearchResult', hash);
		}
	}
}
	
function feedbackClick(label, feedback) {
			
				
	var mail = document.createElement("a");
			
	emailAddress = "mailto:globaltechnicalwriters@experian.com?";
	emailSubject = "subject=PowerCurve%20Help%20and%20Documentation%20Feedback%20-%20" + document.URL + "%20-%20" + label + "&"; 
	emailBody = "body=Thank%20you%20for%20your%20feedback.%20As%20we%20are%20continuously%20trying%20to%20improve%20our%20help%20and%20documentation%2C%20we%20would%20appreciate%20it%20if%20you%20would%20use%20the%20space%20below%20to%20provide%20us%20with%20any%20additional%20information.%0A%0APlease%20note%3A%20%20For%20any%20queries%20or%20comments%20not%20related%20to%20the%20help%20or%20documentation%2C%20please%20contact%20your%20local%20Experian%20office.%20"; 
	mail.href = emailAddress + emailSubject + emailBody;
	mail.click();
		
	localSendToGA(label);	}
				
			/*]]>*/
			